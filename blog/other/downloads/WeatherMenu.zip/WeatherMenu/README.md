# PlayerSize
SourceMod plugin for [IOSoccer](https://github.com/romdi/iosoccer-game/tree/master) This plugin helps you to change the weather & ambient from the stadium easily. 
For any questions, please contact me on Discord: inactivoo.

# AD
Made for [Vertex Arena](http://dsc.gg/vertexar) Community.

## Installation
1. Place `weather.smx` in your `addons/sourcemod/plugins` folder.
2. Restart your server or run `sm plugins load weather` in your server console.

## Usage
Commands:
- `!weather`

## Configuration
- To change player sizes, edit the `weather.sp` file and recompile.

## Translations
- You can change the translations easily in your `addons/sourcemod/translations` folder

## Contributing
Contributions are welcome! Please fork the repository and submit a pull request.
